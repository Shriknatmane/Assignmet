package Assignment14;

public interface Shape {
	 void area(int a);
	 void sidesOfShape();

}
