package Assignment13;

public interface Movie {
	
	void moviename();
	void price(int a);
void collection(int a,int b);

}
