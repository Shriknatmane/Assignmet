package Assignment13;

public class moviefactory {
	public static Movie getfirstObject()
	{
		return new movie12_3();
	}
	
	public static Movie getsecondObject()
	{
		return new movie4_7();
	}
	
	public static Movie getthirdObject()
	{
		return  new movie9_12();
	}
	

}
