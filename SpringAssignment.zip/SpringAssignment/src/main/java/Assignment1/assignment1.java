package Assignment1;

public class assignment1 {
	
	
	private assignment1()
	 {
		 System.out.println("Assignment1 Constructor Is called");
	 }
	 public static assignment1 getObjassignment1()
	 {	 
		 return new assignment1();
	 }
	 public void show()
	 {
		 System.out.println("Show Method");	 		
	 }
	}


