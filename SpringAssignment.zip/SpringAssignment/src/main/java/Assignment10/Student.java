package Assignment10;

import java.util.Map;

public class Student {
	
private Map<String,Float> studdetails;
	
	
	
	
	public Map<String, Float> getStuddetails() {
		return studdetails;
	}


	public void setStuddetails(Map<String, Float> studdetails) {
		this.studdetails = studdetails;
	}


	public Student() {
	
	}


	public Student(Map<String, Float> studdetails) {
		
		this.studdetails = studdetails;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
