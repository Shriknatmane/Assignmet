package Assignment7;

public class Array2 {
	
	int b[];

	public int[] getB() {
		return b;
	}

	public void setB(int[] b) {
		this.b = b;
	}
	
	public void show()
	{
		for(int i=0;i<b.length;i++)
		{
			System.out.println(b[i]);
		}
	}

}
	
	
	
	


